# CS 194-26 Final Project
# Tour into the Picture [Starter Code; Intentionally Unfinished and Possibly Buggy]
# Owen Jow | December 2016

"""tip.py
We contain in `tip.py` the bulk of our implementation for TIP.
If `main.py` is interface stuff and `homography.py` is homography stuff,
then `tip.py` is everything else.
"""

from main import imname
from homography import rectify

"""YOUR CODE HERE."""
