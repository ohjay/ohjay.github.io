# CS 194-26 Final Project
# Tour into the Picture [Starter Code; Intentionally Unfinished and Possibly Buggy]
# Owen Jow | December 2016

"""homography.py
Here, we add the homography warping code from the previous project.
It's possible that your functions are named differently / work differently than mine;
in that case, you will need to modify this file as appropriate.
"""

def rectify(im, height, width):
    """YOUR CODE HERE."""
    return im # replace this line, probably
