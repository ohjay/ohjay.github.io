# CS 194-26 Final Project
# Tour into the Picture [Starter Code; Intentionally Unfinished and Possibly Buggy]
# Owen Jow | December 2016

"""main.py
In `main.py`, we allow the user to interface with our program.
A lot of this code has been borrowed or adapted from http://stackoverflow.com/a/23205715.
I also found http://pydoc.net/Python/PyOpenGL-Demo/3.0.1b1/PyOpenGL-Demo.NeHe.lesson16/ useful for texture mapping.
"""

from PIL import Image
import wx
from tip import *

### Parameters (you should edit these)
imname = 'images/sjerome.jpg'

try:
    from wx import glcanvas
    haveGLCanvas = True
except ImportError:
    haveGLCanvas = False

try:
    from OpenGL.GL import *
    from OpenGL.GLU import *
    from OpenGL.GLUT import *
    from OpenGL.GL.shaders import *
    haveOpenGL = True
except ImportError:
    haveOpenGL = False

class GUI(wx.App):
    def __init__(self):
        wx.App.__init__(self, redirect=False)
    
    def OnInit(self):
        frame = wx.Frame(None, -1, 'TIP', pos=(0, 0),
                style=wx.DEFAULT_FRAME_STYLE, name='tour into the picture')
        menuBar = wx.MenuBar()
        menu = wx.Menu()
        item = menu.Append(wx.ID_EXIT, 'E&xit\tCtrl-Q', 'Exit')
        self.Bind(wx.EVT_MENU, self.OnExitApp, item)
        
        frame.SetMenuBar(menuBar)
        frame.Show(True)
        frame.Bind(wx.EVT_CLOSE, self.OnCloseFrame)
        
        window = MainPanel(frame)
        frame.SetSize((200, 190))
        window.SetFocus()
        self.window = window
        self.SetTopWindow(frame)
        self.frame = frame
        return True
    
    def OnExitApp(self, evt):
        self.frame.Close(True)
    
    def OnCloseFrame(self, evt):
        if hasattr(self, 'window') and hasattr(self.window, 'ShutdownDemo'):
            self.window.ShutdownDemo()
        evt.Skip()

class MainPanel(wx.Panel):
    """Portal interface for the different aspects of our application."""
    
    BUTTON_DEFS = {
        wx.NewId(): ('SelectPointsCanvas', 'Select Points'),
        wx.NewId(): ('TourCanvas', 'Tour')
    }
    
    def __init__(self, parent):
        wx.Panel.__init__(self, parent, -1)
        box = wx.BoxSizer(wx.VERTICAL)
        box.Add((20, 30))
        keys = MainPanel.BUTTON_DEFS.keys()
        keys.sort()
        for k in keys:
            text = MainPanel.BUTTON_DEFS[k][1]
            button = wx.Button(self, k, text)
            box.Add(button, 0, wx.ALIGN_CENTER | wx.ALL, 15)
            self.Bind(wx.EVT_BUTTON, self.OnButton, button)
        
        self.SetAutoLayout(True)
        self.SetSizer(box)
    
    def OnButton(self, evt):
        if not haveGLCanvas:
            dialog = wx.MessageDialog(self, "The GLCanvas class hasn't been included with this wxPython build.",
                    'Sorry', wx.OK | wx.ICON_WARNING)
            dialog.ShowModal()
            dialog.destroy()
        elif not haveOpenGL:
            dialog = wx.MessageDialog(self, 'The OpenGL package could not be found.' \
                    + 'You can obtain it at http://PyOpenGL.sourceforge.net/.',
                    'Sorry', wx.OK | wx.ICON_WARNING)
            dialog.ShowModal()
            dialog.destroy()
        else:
            canvas_classname = MainPanel.BUTTON_DEFS[evt.GetId()][0]
            canvas_class = eval(canvas_classname)
            frame = wx.Frame(None, -1, canvas_classname, size=(panelWidth, panelHeight),
                    pos=(220, 0), style=wx.MINIMIZE)
            canvas_class(frame) # e.g. SelectPointsCanvas(...) or TourCanvas(...)
            frame.Show(True)
    
class CanvasBase(glcanvas.GLCanvas):
    def __init__(self, parent):
        glcanvas.GLCanvas.__init__(self, parent, -1)
        self.init = False
        self.context = glcanvas.GLContext(self)
        self.parent = parent
        
        # Mouse positioning
        self.prevX = self.x = 30
        self.prevY = self.y = 30
        self.size = None
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBackground)
        self.Bind(wx.EVT_SIZE, self.OnSize)
        self.Bind(wx.EVT_PAINT, self.OnPaint)
        self.Bind(wx.EVT_LEFT_DOWN, self.OnMouseDown)
        self.Bind(wx.EVT_LEFT_UP, self.OnMouseUp)
        self.Bind(wx.EVT_MOTION, self.OnMouseMotion)
        self.Bind(wx.EVT_CHAR_HOOK, self.OnKey)
    
    def OnKey(self, evt):
        if evt.GetKeyCode() == wx.WXK_RETURN:
            self.parent.Close()
        
    def OnEraseBackground(self, evt):
        pass
    
    def OnSize(self, evt):
        wx.CallAfter(self.DoSetViewport)
        evt.Skip()
    
    def DoSetViewport(self):
        size = self.size = self.GetClientSize()
        self.SetCurrent(self.context)
        glViewport(0, 0, size.width, size.height)
    
    def OnPaint(self, evt):
        dc = wx.PaintDC(self)
        self.SetCurrent(self.context)
        if not self.init:
            self.InitGL()
            self.init = True
        self.OnDraw()
    
    def OnMouseDown(self, evt):
        self.CaptureMouse()
        self.x, self.y = self.prevX, self.prevY = evt.GetPosition()
    
    def OnMouseUp(self, evt):
        self.ReleaseMouse()
    
    def OnMouseMotion(self, evt):
        if evt.Dragging() and evt.LeftIsDown():
            self.prevX, self.prevY = self.x, self.y
            self.x, self.y = evt.GetPosition()
            self.Refresh(False)

class SelectPointsCanvas(CanvasBase):
    """Has the user specify the vanishing point and back plane of the scene."""
    
    def __init__(self, parent):
        CanvasBase.__init__(self, parent)
        self.mouseDown = False
    
    def OnMouseDown(self, evt):
        CanvasBase.OnMouseDown(self, evt)
        self.mouseDown = True
        
    def OnMouseUp(self, evt):
        CanvasBase.OnMouseUp(self, evt)
        self.mouseDown = False
        
    def OnMouseMotion(self, evt):
        if evt.Dragging() and evt.LeftIsDown():
            self.x, self.y = evt.GetPosition()
            self.Refresh(False)
    
    def InitGL(self):
        image = Image.open(imname)
        self.ix, self.iy = image.size
        image = image.tostring('raw', 'RGBX', 0, -1)
        glBindTexture(GL_TEXTURE_2D, glGenTextures(1))
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, 3, self.ix, self.iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_TEXTURE_2D)
        glShadeModel(GL_SMOOTH)
        
        # Set viewing projection
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluOrtho2D(0, panelWidth, 0, panelHeight)
        
        # Position viewer
        glMatrixMode(GL_MODELVIEW)
    
    def OnDraw(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # For easier reading
        topLeft, bottomRight, vanishing, topRight, bottomLeft = userInput + inferred
        
        # Update points (if necessary)
        if self.mouseDown:
            if not (self.x < topLeft[0] - 30 or self.x > topLeft[0] + 30 \
                    or panelHeight - self.y < topLeft[1] - 30 or panelHeight - self.y > topLeft[1] + 30):
                # Move the top left point
                topLeft = (self.x, panelHeight - self.y)
                userInput[0] = topLeft
                inferred[0] = (inferred[0][0], topLeft[1])
                inferred[1] = (topLeft[0], inferred[1][1])
                topRight, bottomLeft = inferred
            elif not (self.x < bottomRight[0] - 30 or self.x > bottomRight[0] + 30 \
                    or panelHeight - self.y < bottomRight[1] - 30 or panelHeight - self.y > bottomRight[1] + 30):
                # Move the bottom right point
                bottomRight = (self.x, panelHeight - self.y)
                userInput[1] = bottomRight
                inferred[0] = (bottomRight[0], inferred[0][1])
                inferred[1] = (inferred[1][0], bottomRight[1])
                topRight, bottomLeft = inferred
            elif not (self.x < vanishing[0] - 30 or self.x > vanishing[0] + 30 \
                    or panelHeight - self.y < vanishing[1] - 30 or panelHeight - self.y > vanishing[1] + 30):
                # Move the vanishing point
                vanishing = (self.x, panelHeight - self.y)
                userInput[2] = vanishing
        
        # Draw points
        glDisable(GL_TEXTURE_2D)
        glPointSize(10)
        glColor3f(0.196, 0.804, 0.196)
        glBegin(GL_POINTS)
        for x, y in userInput[:2]:
            glVertex2f(x, y)
        glVertex2f(*userInput[2])
        glEnd()
        
        # Draw lines
        glLineWidth(5)
        glColor3f(0.0, 1.0, 1.0)
        glBegin(GL_LINES)
        
        # Horizontal lines
        glVertex2f(*topLeft); glVertex2f(*topRight)
        glVertex2f(*topLeft); glVertex2f(*bottomLeft)
        glVertex2f(*bottomRight); glVertex2f(*topRight)
        glVertex2f(*bottomRight); glVertex(*bottomLeft)
        
        # Diagonal lines
        glVertex2f(*vanishing)
        glVertex2f(*[v_val + 5 * (c_val - v_val) for c_val, v_val in zip(topLeft, vanishing)])
        glVertex2f(*vanishing)
        glVertex2f(*[v_val + 5 * (c_val - v_val) for c_val, v_val in zip(topRight, vanishing)])
        glVertex2f(*vanishing)
        glVertex2f(*[v_val + 5 * (c_val - v_val) for c_val, v_val in zip(bottomLeft, vanishing)])
        glVertex2f(*vanishing)
        glVertex2f(*[v_val + 5 * (c_val - v_val) for c_val, v_val in zip(bottomRight, vanishing)])
        glEnd()
        glEnable(GL_TEXTURE_2D)
        
        # Draw the image that we're selecting points over
        glBegin(GL_QUADS)
        glNormal3f(0.0,  0.0, -1.0)
        glTexCoord2f(1.0, 0.0); glVertex2f(self.ix, 0)
        glTexCoord2f(1.0, 1.0); glVertex2f(self.ix, self.iy)
        glTexCoord2f(0.0, 1.0); glVertex2f(0, self.iy)
        glTexCoord2f(0.0, 0.0); glVertex2f(0, 0)
        glEnd()
        
        self.SwapBuffers()

class TourCanvas(CanvasBase):
    """Constructs the 3D box model and allows the user to shift the perspective inside of it."""
    
    def InitGL(self):
        # Set viewing projection
        glMatrixMode(GL_PROJECTION)
        glFrustum(-0.5, 0.5, -0.5, 0.5, 1.0, 10.0)
        
        # Position viewer
        glMatrixMode(GL_MODELVIEW)
        glTranslatef(0.0, 0.0, -2.0)
        
        # Shaders
        self.program = compileProgram(
            compileShader("""
                    void main() {
                        gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
                        gl_TexCoord[1] = gl_MultiTexCoord1;
                        gl_TexCoord[2] = gl_MultiTexCoord2;
                        gl_TexCoord[3] = gl_MultiTexCoord3;
                        gl_TexCoord[4] = gl_MultiTexCoord4;
                        gl_TexCoord[5] = gl_MultiTexCoord5;
                    }
            """, GL_VERTEX_SHADER),
            compileShader("""
                    uniform sampler2D texture1;
                    uniform sampler2D texture2;
                    uniform sampler2D texture3;
                    uniform sampler2D texture4;
                    uniform sampler2D texture5;
                    void main() {
                        if (gl_TexCoord[1].st[1] >= 0.0) {
                            vec4 color1 = texture2D(texture1, gl_TexCoord[1].st);
                            gl_FragColor = color1;
                        } else if (gl_TexCoord[2].st[1] >= 0.0) {
                            vec4 color2 = texture2D(texture2, gl_TexCoord[2].st);
                            gl_FragColor = color2;
                        } else if (gl_TexCoord[3].st[1] >= 0.0) {
                            vec4 color3 = texture2D(texture3, gl_TexCoord[3].st);
                            gl_FragColor = color3;
                        } else if (gl_TexCoord[4].st[1] >= 0.0) {
                            vec4 color4 = texture2D(texture4, gl_TexCoord[4].st);
                            gl_FragColor = color4;
                        } else {
                            vec4 color5 = texture2D(texture5, gl_TexCoord[5].st);
                            gl_FragColor = color5;
                        }
                    }
            """, GL_FRAGMENT_SHADER),
        )
        
        # Texture 1 (back plane)
        image = Image.open(imname) # replace this with your own image
        ix, iy = image.size
        image = image.tostring('raw', 'RGBX', 0, -1)
        glActiveTexture(GL_TEXTURE1)
        texture1 = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture1) 
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, 3, ix, iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        glGenerateMipmap(GL_TEXTURE_2D)

        # Texture 2 (top plane)
        image = Image.open(imname) # replace this with your own image
        ix, iy = image.size
        image = image.tostring('raw', 'RGBX', 0, -1)
        glActiveTexture(GL_TEXTURE2)
        texture2 = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture2) 
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, 3, ix, iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        glGenerateMipmap(GL_TEXTURE_2D)
        
        # Texture 3 (bottom plane)
        image = Image.open(imname) # replace this with your own image
        ix, iy = image.size
        image = image.tostring('raw', 'RGBX', 0, -1)
        glActiveTexture(GL_TEXTURE3)
        texture3 = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture3) 
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, 3, ix, iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        glGenerateMipmap(GL_TEXTURE_2D)
        
        # Texture 4 (right plane)
        image = Image.open(imname) # replace this with your own image
        ix, iy = image.size
        image = image.tostring('raw', 'RGBX', 0, -1)
        glActiveTexture(GL_TEXTURE4)
        texture4 = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture4) 
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, 3, ix, iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        glGenerateMipmap(GL_TEXTURE_2D)
        
        # Texture 5 (left plane)
        image = Image.open(imname) # replace this with your own image
        ix, iy = image.size
        image = image.tostring('raw', 'RGBX', 0, -1)
        glActiveTexture(GL_TEXTURE5)
        texture5 = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture5) 
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, 3, ix, iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        glGenerateMipmap(GL_TEXTURE_2D)

        glActiveTexture(GL_TEXTURE1)
        glBindTexture(GL_TEXTURE_2D, texture1) 
        glActiveTexture(GL_TEXTURE2)
        glBindTexture(GL_TEXTURE_2D, texture2)
        glActiveTexture(GL_TEXTURE3)
        glBindTexture(GL_TEXTURE_2D, texture3)
        glActiveTexture(GL_TEXTURE4)
        glBindTexture(GL_TEXTURE_2D, texture4)
        glActiveTexture(GL_TEXTURE5)
        glBindTexture(GL_TEXTURE_2D, texture5)
        glUseProgram(self.program)
        uniformLocation1 = glGetUniformLocation(self.program, 'texture1')
        glUniform1i(uniformLocation1, 1)
        uniformLocation2 = glGetUniformLocation(self.program, 'texture2')
        glUniform1i(uniformLocation2, 2)
        uniformLocation3 = glGetUniformLocation(self.program, 'texture3')
        glUniform1i(uniformLocation3, 3)
        uniformLocation4 = glGetUniformLocation(self.program, 'texture4')
        glUniform1i(uniformLocation4, 4)
        uniformLocation5 = glGetUniformLocation(self.program, 'texture5')
        glUniform1i(uniformLocation5, 5)

        glEnable(GL_DEPTH_TEST)
    
    def OnDraw(self):
        # Clear the color and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # Draw the five faces of our 3D box
        glBegin(GL_QUADS)

        # Back face of box volume
        glNormal3f(0.0, 0.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE1,  0.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(-0.5, -0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1,  0.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1,  1.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1,  1.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, -0.5, -0.5)

        # Top face of box volume
        glNormal3f(0.0, 1.0, 0.0)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2,  1.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, 0.5, 0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2,  1.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2,  0.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2,  0.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(-0.5, 0.5, 0.5)

        # Bottom face of box volume
        glNormal3f(0.0, -1.0, 0.0)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3,  0.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(-0.5, -0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3,  1.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3,  1.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, -0.5, 0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3,  0.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(-0.5, -0.5, 0.5)

        # Right face of box volume
        glNormal3f(1.0, 0.0, 0.0)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4,  0.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, -0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4,  0.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, 0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4,  1.0,  1.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, 0.5, 0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4,  1.0,  0.0)
        glMultiTexCoord2f(GL_TEXTURE5, -1.0, -1.0)
        glVertex3f(0.5, -0.5, 0.5)

        # Left face of box volume
        glNormal3f(-1.0, 0.0, 0.0)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5,  1.0,  0.0)
        glVertex3f(-0.5, -0.5, -0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5,  0.0,  0.0)
        glVertex3f(-0.5, -0.5, 0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5,  0.0,  1.0)
        glVertex3f(-0.5, 0.5, 0.5)
        glMultiTexCoord2f(GL_TEXTURE1, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE2, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE3, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE4, -1.0, -1.0)
        glMultiTexCoord2f(GL_TEXTURE5,  1.0,  1.0)
        glVertex3f(-0.5, 0.5, -0.5)
        glEnd()

        if self.size is None:
            self.size = self.GetClientSize()
        w, h = self.size
        w = max(w, 1.0)
        h = max(h, 1.0)
        xScale = 180.0 / w
        yScale = 180.0 / h
        glRotatef((self.y - self.prevY) * yScale, 1.0, 0.0, 0.0)
        glRotatef((self.x - self.prevX) * xScale, 0.0, 1.0, 0.0)

        self.SwapBuffers()

if __name__ == '__main__':
    panelWidth, panelHeight = Image.open(imname).size
    userInput = [ # top left, bottom right, vanishing point
        (panelWidth // 4, panelHeight * 3 // 4),
        (panelWidth * 3 // 4, panelHeight // 4),
        (panelWidth // 2, panelHeight // 2),
    ]
    inferred = [ # top right, bottom left
        (panelWidth * 3 // 4, panelHeight * 3 // 4),
        (panelWidth // 4, panelHeight // 4),
    ]
    GUI().MainLoop()
